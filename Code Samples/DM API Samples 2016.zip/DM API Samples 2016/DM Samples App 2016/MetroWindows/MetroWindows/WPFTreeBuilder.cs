﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Windows.Controls;
using System.IO;
using System.Windows.Media;
using System.Windows;

namespace WPFTreeBuilder
{
    public static class WPFTreeBuilder
    {
        
// Load XML File to TreeView
    public static void Load(string XMLFilePath, TreeView EntityModelTreeView)
    {
    XmlDocument XMLEntities;
    try
    {
        XMLEntities = new XmlDocument();
        XMLEntities.Load(XMLFilePath);

        EntityModelTreeView.Items.Clear();

        TreeViewItem root = new TreeViewItem();
        root.Header = XMLEntities.DocumentElement.Name;
        EntityModelTreeView.Items.Add(root);

        TreeViewItem ChildNode = new TreeViewItem();
        ChildNode = (TreeViewItem)EntityModelTreeView.Items[0];
        addEntityModelTreeViewNode(XMLEntities.DocumentElement, ChildNode);                                

    }
    catch (Exception ex)
    {
        ex.ToString();
    }
}  
      
private static void addEntityModelTreeViewNode(XmlNode xmlEntityNode, TreeViewItem TreeViewNodes)
{
    XmlNode entityModelXMLNode;
    TreeViewItem entityModelTreeNode;
    XmlNodeList entityModelXMLNodes;
    String entityName;

    if (xmlEntityNode.HasChildNodes)
    {
        entityModelXMLNodes = xmlEntityNode.ChildNodes;

        for (int x = 0; x <= entityModelXMLNodes.Count - 1; x++)
        {
            string s = entityModelXMLNodes.ToString();
            int c = entityModelXMLNodes.Count;
            entityModelXMLNode = xmlEntityNode.ChildNodes[x];

            string p = xmlEntityNode.Name;
            string val = xmlEntityNode.ChildNodes[x].Name;
            if (entityModelXMLNode.Name == "Entity")
            {
                entityName = entityModelXMLNode.Attributes["Name"].InnerText;                       

                int i = TreeViewNodes.Items.Add(new TreeViewItem()
                {
                    Header = entityName                     
                });
            }
            else if (entityModelXMLNode.Name == "Property")
            {
                String AttributeName = entityModelXMLNode.Attributes["Name"].InnerText;
                       
                int i = TreeViewNodes.Items.Add(new TreeViewItem()
                {
                    Header = AttributeName                           
                });
            }                   
            else
            {
                int i = TreeViewNodes.Items.Add(new TreeViewItem()
                {
                    Header = entityModelXMLNode.Name
                });
            }

            entityModelTreeNode = TreeViewNodes.Items[x] as TreeViewItem;
            addEntityModelTreeViewNode(entityModelXMLNode, entityModelTreeNode);
        }
    }
}





public static string GetSelectedParentNode(TreeViewItem item)
{
    DependencyObject parent = VisualTreeHelper.GetParent(item);
    ItemsControl ParentNode;
    string MyValue = string.Empty;

    while (!(parent is TreeViewItem || parent is TreeView))
    {
        parent = VisualTreeHelper.GetParent(parent);
    }


    ParentNode = (ItemsControl)parent;

    if (item != null)
    {


        TreeViewItem treeitem = ParentNode as TreeViewItem;
        MyValue = treeitem.Header.ToString();
    }

    return MyValue;
}
        



//public static void ParseXml(XmlDocument xmlFile, TreeView tv, string att)
//{

//    string selectedNode = tv.SelectedItem.ToString();
    
//   // XmlNodeList nodes = xmlFile.SelectNodes("//"+ selectedNode);
//    XmlNode sel = xmlFile.ge
//    foreach (XmlNode node in nodes)
//    {
//        string id = node.Attributes[att].InnerText;
//        // Do whatever you need to with each ID here.

//        //XmlNodeList nodes = xmlFile.SelectNodes("//Engagement[@id]/@id");
//    }
//}



        
        
        
        
 public static void ParseXML2( string path, string ParentNodeName, string AttrbuteName  )
{
    XmlDocument xml = new XmlDocument();
    xml.LoadXml(path);  // suppose that str string contains "<Names>...</Names>"

    XmlNodeList xnList = xml.SelectNodes("/Samples/Entity[@type='"+ParentNodeName+"']");
    foreach (XmlNode xn in xnList)
    {
        Console.WriteLine(xn.InnerText);
    }

}




public static void LoadXMLDescript(string CB, RichTextBox RTB) //OverLoadedMethod for Checkboxes 
{
    try
    {
        string XMLDecriptions = System.AppDomain.CurrentDomain.BaseDirectory + "\\Resources\\Descriptions.xml";

        XmlDocument xmlDoc = new XmlDocument(); //* create an xml document object.
        xmlDoc.Load(XMLDecriptions); //* load the XML document from the specified file.

        RTB.SelectAll();
        RTB.Selection.Text = "";
        // RTB.Text = string.Empty;
        string RegLoc = string.Empty;
        string RegDescrip = string.Empty;

        XmlElement root = xmlDoc.DocumentElement;
        XmlNodeList nodes = root.SelectNodes("key");
        StringBuilder sb = new StringBuilder();

        foreach (XmlNode node in nodes)
        {


            foreach (XmlNode child in node.ChildNodes)


                if (child.FirstChild.Value.ToString() == CB.ToString())
                {

                    XmlNode Loc = child.NextSibling;

                    RegLoc = Loc.InnerText;
                    RegDescrip = Loc.NextSibling.InnerText;


                }


        }

        //tt.SetToolTip(CB, RegLoc + RegDescrip);
        RTB.AppendText(RegLoc + RegDescrip);
    }

    catch (Exception ex)
    {
        // MessageBox.Show(ex.Message);
    }

}





        
    }
}
