﻿using DMAPISamples2016;
using System.Windows;
using System.Windows.Input;
using System.Xml;
using System.Linq;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Windows.Controls;
using WPFTreeBuilder;
using System.Windows.Media;
using System.IO;
using System.Windows.Documents;


namespace DMAPISamples2016
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       
     string DMAPIFile =System.AppDomain.CurrentDomain.BaseDirectory + "\\DMAPITree.xml";
     string DMEXTFile = System.AppDomain.CurrentDomain.BaseDirectory + "\\DMEXTAPITree.xml";
     string DMWSFile = System.AppDomain.CurrentDomain.BaseDirectory + "\\DMWSAPITree.xml";
     string RestAPIFile = System.AppDomain.CurrentDomain.BaseDirectory + "\\RESTAPITree.xml";
     string SamplesLoc = System.AppDomain.CurrentDomain.BaseDirectory + "\\Samples\\";
       
        
        
        public MainWindow()
        {
            InitializeComponent();
        }

        private void PART_TITLEBAR_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void PART_CLOSE_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void PART_MAXIMIZE_RESTORE_Click(object sender, RoutedEventArgs e)
        {
            if (this.WindowState == System.Windows.WindowState.Normal)
            {
                this.WindowState = System.Windows.WindowState.Maximized;
            }
            else
            {
                //
               this.WindowState = System.Windows.WindowState.Normal;
            this.Height =500;
            this.Width = 1000;
            }
        }

        private void PART_MINIMIZE_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = System.Windows.WindowState.Minimized;
        }

        private void TabControl_SelectionChanged_1(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {

        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {

            this.WindowState = System.Windows.WindowState.Maximized;
            DMAPI_RB.IsChecked = true;
            CSharpRB.IsChecked = true;

            string sourceXMLFile = DMAPIFile;           
            WPFTreeBuilder.WPFTreeBuilder.Load(sourceXMLFile, tView);
            XmlDocument xdoc = new XmlDocument();
            xdoc.Load(sourceXMLFile);
            RTB.Document.Blocks.Clear();
            

            tView.Items.OfType<TreeViewItem>().ToList().ForEach(ExpandAllNodes);
          
        }


        private void ExpandAllNodes(TreeViewItem treeItem)
        {
            treeItem.IsExpanded = true;
            foreach (var childItem in treeItem.Items.OfType<TreeViewItem>())
            {
                ExpandAllNodes(childItem);
            }
        }


        private void tView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {

            LoadCode();


       
        }


        public void LoadCode()
        {
           string codeSelected= string.Empty;
            string sourceXMLFile = string.Empty;
            string sampleSelected = string.Empty;
            string fileLocation = string.Empty;
           

            if (VBRB.IsChecked == true)
            {
                codeSelected = "VB";
            }

            else
            {
                codeSelected = "CSharp";
            }

            if(DMAPI_RB.IsChecked==true)
            {
                sourceXMLFile = DMAPIFile;

            }

            if (ExtAPI_RB.IsChecked == true)
            {

                sourceXMLFile = DMEXTFile;
            }


            if (WebService_RB.IsChecked == true)
            {
                sourceXMLFile = DMWSFile;
            }

            if (RESTAPI_RB.IsChecked == true)
            {
                sourceXMLFile = RestAPIFile;
            }
         
            XmlDocument xdoc = new XmlDocument();
            xdoc.Load(sourceXMLFile);

            
            string treeCurrentItem= string.Empty;
            TreeViewItem item = (TreeViewItem)tView.SelectedItem;
            if (item != null)
            {



                string nodeName = item.Header.ToString();
               
             sampleSelected =  GetFileElements(xdoc, nodeName, codeSelected);
             
             
               
               
            }



            fileLocation = SamplesLoc + sampleSelected;

            if (!string.IsNullOrEmpty(sampleSelected))
            {

                RTB.Document.Blocks.Clear();

                try
                {
                    FileStream fs = new FileStream(fileLocation, FileMode.Open);

                    RTB.Selection.Load(fs, DataFormats.Rtf);
                    fs.Close();
                   
                    //RTB.Selection.Load(new FileStream(fileLocation, FileMode.Open), DataFormats.Rtf);
                }


                catch  
                {
                    fileLocation = SamplesLoc + "SampleError.rtf";

                     FileStream fs = new FileStream(fileLocation, FileMode.Open);

                    RTB.Selection.Load(fs, DataFormats.Rtf);
                    fs.Close();
                    
                    //RTB.Selection.Load(new FileStream(fileLocation, FileMode.Open), DataFormats.Rtf);
                }
            }

            else
            {
                return;
            }
            
}



        public string GetFileElements( XmlDocument doc, string NodeName,  string attribute) // Used to get the VB or Csharp attribute 
        {
            string Name;
            string attributeVal = string.Empty;
            XmlNodeList PropList = doc.GetElementsByTagName("Property");
            foreach (XmlNode att in PropList)
            {
                 Name = att.Attributes["Name"].InnerText;

                 if (Name == NodeName)
                 {
                     attributeVal = att.Attributes[attribute].InnerText;


                 }
            }


            return attributeVal;
        
        }

        private void VBRB_Checked(object sender, RoutedEventArgs e)
        {


            LoadCode();

        }

        private void CSharpRB_Checked(object sender, RoutedEventArgs e)
        {
            LoadCode();
        }

        private void ExtAPI_RB_Checked(object sender, RoutedEventArgs e)
        {
            string sourceXMLFile = DMEXTFile;
            WPFTreeBuilder.WPFTreeBuilder.Load(sourceXMLFile, tView);
            XmlDocument xdoc = new XmlDocument();
            xdoc.Load(sourceXMLFile);
            RTB.Document.Blocks.Clear();
            tView.Items.OfType<TreeViewItem>().ToList().ForEach(ExpandAllNodes);
        }

        private void DMAPI_RB_Checked(object sender, RoutedEventArgs e)
        {
            string sourceXMLFile = DMAPIFile;
            WPFTreeBuilder.WPFTreeBuilder.Load(sourceXMLFile, tView);
            XmlDocument xdoc = new XmlDocument();
            xdoc.Load(sourceXMLFile);
            RTB.Document.Blocks.Clear();


            tView.Items.OfType<TreeViewItem>().ToList().ForEach(ExpandAllNodes);
          
        }

        private void WebService_RB_Checked(object sender, RoutedEventArgs e)
        {
            string sourceXMLFile = DMWSFile;
            WPFTreeBuilder.WPFTreeBuilder.Load(sourceXMLFile, tView);
            XmlDocument xdoc = new XmlDocument();
            xdoc.Load(sourceXMLFile);
            RTB.Document.Blocks.Clear();
            tView.Items.OfType<TreeViewItem>().ToList().ForEach(ExpandAllNodes);
        }

        private void RESTAPI_RB_Checked(object sender, RoutedEventArgs e)
        {

             string sourceXMLFile = RestAPIFile;
            WPFTreeBuilder.WPFTreeBuilder.Load(sourceXMLFile, tView);
            XmlDocument xdoc = new XmlDocument();
            xdoc.Load(sourceXMLFile);
            RTB.Document.Blocks.Clear();
            tView.Items.OfType<TreeViewItem>().ToList().ForEach(ExpandAllNodes);
        }


        








        //private void TreeViewItem_OnItemSelected(object sender, RoutedEventArgs e)
        //{
        //    TreeViewItem item = e.OriginalSource as TreeViewItem;
        //    if (item != null)
        //    {
        //        ItemsControl parent = GetSelectedTreeViewItemParent(item);

        //        TreeViewItem treeitem = parent as TreeViewItem;
        //        string MyValue = treeitem.Header.ToString();//Gets you the immediate parent
        //    }
        //}
        //public ItemsControl GetSelectedTreeViewItemParent(TreeViewItem item)
        //{
        //    DependencyObject parent = VisualTreeHelper.GetParent(item);
        //    while (!(parent is TreeViewItem || parent is TreeView))
        //    {
        //        parent = VisualTreeHelper.GetParent(parent);
        //    }

        //    return parent as ItemsControl;
        //}

       
       

    }


}
